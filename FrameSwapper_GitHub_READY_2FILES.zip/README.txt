FrameSwapper — сборка APK с телефона

1. Создайте пустой GitHub repository.
2. Загрузите в него FrameSwapper-source.zip.
3. Создайте файл .github/workflows/build.yml и вставьте содержимое файла build.yml из этого архива.
4. Actions -> Build FrameSwapper APK -> Run workflow.
5. После сборки скачайте Artifact FrameSwapper-APK.
